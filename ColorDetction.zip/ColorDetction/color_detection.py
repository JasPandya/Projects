# importing opencv2 module
import cv2
import argparse
import pandas as pd

# declaring global variables
b = g = r = xpos = ypos = 0
clicked = False

# The first step in using the argparse is creating an ArgumentParser object
# The ArgumentParser object will hold all the information necessary to parse the command line into Python data types.

parser = argparse.ArgumentParser()

# Filling an ArgumentParser with information about program arguments is done by making calls to the add_argument() method.

parser.add_argument('-i', '--image', required=True, help="Image Path")
args = vars(parser.parse_args())
img_path = args['image']

# Reading image with opencv

img = cv2.imread(img_path)

# reading the colors from the csv file and giving names to each column
# pd.read_csv() reads the CSV file and loads it into the pandas DataFrame. We have assigned each column with a name for easy accessing.

index = ["color", "color_name", "hex", "R", "G", "B"]
csv_dataframe = pd.read_csv('colors.csv', names=index, header=None)

# defining the callback function for the mouse event in the window
# It will calculate the rgb values of the pixel which we double click.
def draw_function(event, x, y, flags, param):
    # if event is left double click only then do we proceed to find the r g b values
    if event == cv2.EVENT_LBUTTONDBLCLK:
        global b, g, r, xpos, ypos, clicked
        clicked = True
        xpos = x
        ypos = y
        b, g, r = img[y, x]
        b = int(b)
        g = int(g)
        r = int(r)

# We have the r,g and b values.
# Now, we need another function which will return us the color name from RGB values.
# To get the color name, we calculate a distance(d) which tells us how close we are to color
# Choose the one having minimum distance.
# function to calculate minimum distance from all colors and get the most matching color i.e. one with least distance
def getColorName(R, G, B):
    minimum = 10000
    for i in range(len(csv_dataframe)):
        d = abs(R - int(csv_dataframe.loc[i, "R"])) + abs(G - int(csv_dataframe.loc[i, "G"])) + abs(B - int(csv_dataframe.loc[i, "B"]))
        if(d<=minimum):
            minimum = d
            cname = csv_dataframe.loc[i, "color_name"]
    return cname


# First, we create a window in which the input image will display.
# Then, we set a callback function which will be called when a mouse event happens.
# With these lines, we named our window as ‘image’
# set a callback function which will call the draw_function() whenever a mouse event occurs.

cv2.namedWindow('image', cv2.WINDOW_NORMAL)
cv2.setMouseCallback('image', draw_function)

while(1):
    cv2.imshow("image", img)
    # creating text to show user on how to quit the program
    quitText = "Please press the \"esc\" key to quit the program."

    # put the escape text at the bottom of the window
    cv2.putText(img, quitText, (20, 1700), 2, 1, (255, 255, 255), 2, cv2.LINE_AA)

    if clicked:

        #display the rectangle in which you will display the color name
        cv2.rectangle(img, (20,20), (850,60), (b, g, r), -1)

        #creating the text string to be displayed in the rectangle (Color name and RGB values)
        text = getColorName(r, g, b) + ' R=' + str(r) + ' G=' + str(g) + ' B=' + str(b) + '    X=' + str(xpos) + ' Y=' + str(ypos)

        #put the text into the rectangle created
        cv2.putText(img, text, (50,50), 2, 0.8, (255, 255, 255), 2, cv2.LINE_AA)

        #if the color is very light, we'll use the font color as black to display the text
        if (r+g+b>=600):
            cv2.putText(img, text, (50, 50), 2, 0.8, (0, 0, 0), 2, cv2.LINE_AA)

        clicked = False

    #Break if the user hits the 'esc' key
    if (cv2.waitKey(20) & 0xFF == 27):
        break

cv2.destroyAllWindows()




