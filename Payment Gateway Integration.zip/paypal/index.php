<html>
    <head>
        <title>
            Paypal Payment Gateway Integration
        </title>
        <style>
        </style>
    </head>
    <body style="background: url(donate.jpg); background-size: 100%;">
        <center><h1><em>The measure of life is not its duration, but its donation.</em></h1></center>
        <div style="position:absolute;top:60px;left:570px;">
            <form action="https://www.sandbox.paypal.com/cgi-bin/webscr" method="post" target="_top">
            <input type="hidden" name="cmd" value="_s-xclick">
            <input type="hidden" name="hosted_button_id" value="XUYYYVJN3JJFE">
            <input type="image" src="https://www.sandbox.paypal.com/en_US/i/btn/btn_donateCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online!">
            <img alt="" border="0" src="https://www.sandbox.paypal.com/en_US/i/scr/pixel.gif" width="1" height="1">
            </form>
        </div>
    </body>
</html>




