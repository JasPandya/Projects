-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 19, 2018 at 04:00 PM
-- Server version: 10.1.25-MariaDB
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dummy`
--

-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `sender` varchar(50) NOT NULL,
  `receiver` varchar(50) NOT NULL,
  `credits` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`sender`, `receiver`, `credits`) VALUES
('Abhishek', 'Farhan', 5000),
('Sam', 'Abhishek', 10000),
('Farhan', 'Abhishek', 10000),
('Rani', 'Girish', 10000),
('Girish', 'Abhishek', 5000),
('Hema', 'Sam', 10000),
('Farhan', 'Rani', 1000),
('Farhan', 'Rani', 1000),
('Farhan', 'Rani', 1000),
('Aishwarya', 'Keerthi', 15000),
('Hema', 'Sam', 4000),
('Rudra', 'Farhan', 3000),
('Farhan', 'Rahul', 8000),
('Rudra', 'Hema', 2000),
('Girish', 'Rahul', 5000),
('Farhan', 'Sam', 12000),
('Keerthi', 'Rudra', 30000),
('Rudra', 'Aishwarya', 1000),
('Keerthi', 'Sam', 15000),
('Sam', 'Rahul', 11000),
('Rahul', 'Sam', 2000),
('Keerthi', 'Sam', 10000);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `name` varchar(25) NOT NULL,
  `email` varchar(100) NOT NULL,
  `current_credits` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`name`, `email`, `current_credits`) VALUES
('Abhishek', 'abhishek@gmail.com', 35000),
('Rahul', 'rahul@gmail.com', 82000),
('Sam', 'sam@gmail.com', 72000),
('Rudra', 'rudra@gmail.com', 74000),
('Keerthi', 'keerthi@gmail.com', 25000),
('Farhan', 'farhan@gmail.com', 80000),
('Girish', 'girish@gmail.com', 20000),
('Hema', 'hema@gmail.com', 108000),
('Rani', 'rani@gmail.com', 143000),
('Aishwarya', 'aishwarya@gmail.com', 76000);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
