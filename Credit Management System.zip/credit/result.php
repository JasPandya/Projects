<?php
    header("refresh:4; url= credit.php");
?>
<?php
    /*Start session*/
    session_start();
?>

<?php
echo "<body style='background-image: url(\"sample.jpg\"); font-family: \"Amatic SC\", cursive;'>";

$receiver = $_GET["rec"];
$credits = $_GET["credits"];
$sender = $_GET["sen"];

$user = 'root';
$pass = '';
$db = 'dummy';

/*Connecting the database */
$db = new mysqli('localhost', $user, $pass, $db) or die("Connection failed.");
/*echo "Connected successfully";*/

echo "<br>";

/*echo "$sender <br>";
echo "$receiver <br>";
echo "$credits<br>";*/

$sql = "SELECT current_credits from user WHERE name=\"$sender\"";
$res = mysqli_query($db,$sql) or die("Bad query: $sql");
$row =  mysqli_fetch_assoc($res);

/*echo "{$row['current_credits']}";*/

if($credits > $row)
{
    echo "Insufficient Balance";
}
else
{
    $sql2 = "UPDATE user SET current_credits = current_credits-$credits WHERE name=\"$sender\"";
    $sql3 = "UPDATE user SET current_credits = current_credits+$credits WHERE name=\"$receiver\"";
    $sql4 = "INSERT INTO transaction (sender,receiver,credits) VALUES ('$sender','$receiver','$credits')";
    $res2 = mysqli_query($db,$sql2) or die("Bad query: $sql2");
    $res3 = mysqli_query($db,$sql3) or die("Bad query: $sql3");
    $res4 = mysqli_query($db,$sql4) or die("Bad query: $sql4");
    echo "<span style=\"color:#AFA;text-align:center;\"><h1>Transaction complete.</h1></span>
        <span style=\"color:#AFA;text-align:center;\"><h1>Transferred $credits from $sender to $receiver</h1></span>";
}

?>
