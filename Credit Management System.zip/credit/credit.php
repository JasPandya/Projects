<?php
    session_start();
?>

<form  action="result.php" method="get">
<?php
echo "<body style='background-image: url(\"sample.jpg\"); font-family: \"Amatic SC\", cursive;'>";

$user = 'root';
$pass = '';
$db = 'dummy';

/*Connecting the database */
$db = new mysqli('localhost', $user, $pass, $db) or die("Connection failed.");
/*echo "Connected successfully";*/

/*Select each row from the table */
$sql = "SELECT * FROM user";
$result = mysqli_query($db, $sql) or die("Bad Query: $sql");

echo "<div style=\"position:absolute;top:30px;\">";
echo '<span style="color:#AFA;"><b><h3>Select a user to transfer credits from</h3></b></span>';

echo "<select name=\"sen\" required>";
/*Display each name as a drop down */
while($row = mysqli_fetch_assoc($result))
{
    echo "<div style=\"position:absolute;left:50px;top:60px;\">";
    echo "<option value=\"{$row['name']}\"> {$row['name']}</option>";
    echo "</div>";
}
echo "</select>";
echo "</div>";

echo "<div style=\"position:absolute;left:450px;top:30px;\">";
echo "<span style=\"color:#AFA;text-align:center;\"><h3><b>Amount of credits to be transferred<br><br><input type=\"text\" name=\"credits\"></b></h3></span>";
echo "</div>";


$sql2 = "SELECT * FROM user";
$result2 = mysqli_query($db, $sql2) or die("Bad Query: $sql");

echo "<div style=\"position:absolute;left:950px;top:30px;\">";
echo '<span style="color:#AFA;"><b><h3>Select a user to transfer credits to</h3></b></span>';

echo "<select name=\"rec\" required>";
/*Display each name as a drop down */
while($row2 = mysqli_fetch_assoc($result2))
{
    echo "<option value=\"{$row2['name']}\"> {$row2['name']}";
}
echo "</select>";
echo "</div>";

/*Submit button */
echo "<div style=\"position:absolute;left:600px;top:150px;\">";
echo "<span style=\"color:#AFA;text-align:center;\"><h3><input type=\"submit\" value=\"Transfer\"></h3></span>";
echo "</body>";
?>
</form>