<?php
    header('refresh: 3; url= credit.php');
?>
<?php
    echo "<body style='background-image: url(\"sample.jpg\"); font-family: \"Amatic SC\", cursive;'>";
    echo "<div style=\"position:fixed; top:40%; left:35%; color:#AFA;\"><h1><center>Credit Management System</center></h1></div>";
?>
